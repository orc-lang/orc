======================================================
Apache Axis2 0.94 build (January 11, 2006)
Standard Binary Release

http://ws.apache.org/axis2
------------------------------------------------------

This is the Standard Binary release of Axis2.

The lib directory contains;

1. axis2-core-0.94.jar
2. axis2-adb-0.94.jar
3. axis2-codegen-0.94.jar
4. axis2-doom-0.94.jar
5. All 3rd party distributable dependencies of the above jars

The modules directory contains the deployable addressing
module(addressing.mar)

The samples directory contains all the Axis2 module samples
& service samples.

(Please note that this does not include the other WS-* implementation modules, like WS-Security, that are being developed
 within Axis2. Those can be downloaded from http://ws.apache.org/axis2/modules/)
