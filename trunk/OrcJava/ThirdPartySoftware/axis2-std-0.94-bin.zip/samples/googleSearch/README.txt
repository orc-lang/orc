Sample for Google - Search - API
========================================

Running the Sample:
-------------------

First way, Type <ant> command to run the sample.

Second way is the scrip files. Use run.sh or run.bat to run the sample pertaining
to the system you are using.

Help:
-----

Please refer to the sample help page for more details